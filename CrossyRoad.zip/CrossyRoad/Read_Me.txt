Members: Christopher McDonnell, Quang Nguyen

How to run the game:
* Open the Crossy Road file to open Unreal Engine
* Open Maps in Content
* Choose Gameplay
* Press Play to run the game

https://github.com/CPSC-386-02/Crossy-Road